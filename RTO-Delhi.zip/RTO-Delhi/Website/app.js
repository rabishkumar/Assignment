﻿
var app = angular.module('vehicleApp', []);
var baseAddress = 'http://localhost:49596/VehicleService/api/VehicleService/';
var url = "";
 
app.factory('vehicleFactory', function ($http) {
    return {
        getVehiclesList: function () {
            url = baseAddress + "GetVehiclesList";
            return $http.get(url);
        },
        getVehicle: function (vehicle) {
            url = baseAddress + "GetVehicle/" + vehicle.VehicleId;
            return $http.get(url);
        },
        addVehicle: function (vehicle) {
            url = baseAddress + "AddVehicle";
            //alert(vehicle);
            return $http.post(url, vehicle);
        },
        deleteVehicle: function (vehicle) {
            url = baseAddress + "DeleteVehicle/" + vehicle.VehicleId;
            return $http.delete(url);
        },
        updateVehicle: function (vehicle) {
            url = baseAddress + "ModifyVehicle/" + vehicle.VehicleId;
            return $http.put(url, vehicle);
        }
    };
});
 
app.controller('vehicleController', function PostController($scope, vehicleFactory) {
    $scope.vehicles = [];
    $scope.vehicle = null;
    $scope.editMode = false;
 
    //get Vehicle
    $scope.get = function () {
        $scope.vehicle = this.vehicle;
        $('#viewModal').modal('show');
    };
 
    //get all Vehicles
    $scope.getAll = function () {
        vehicleFactory.getVehiclesList().success(function (data) {
            //alert(data);
            $scope.vehicles = data;
        }).error(function (data) {
            $scope.error = "An Error has occured while Loading vehicles! " + data.ExceptionMessage;
        });
    };
 
    // add vehicle
    $scope.add = function () {
        var currentVehicle = this.vehicle;
        console.warn(currentVehicle);
        if (currentVehicle != null && currentVehicle.CustomerName != null && currentVehicle.CustomerAddress && currentVehicle.CustomerContactNo) {
            vehicleFactory.addVehicle(currentVehicle).success(function (data) {
                $scope.addMode = false;
                currentVehicle.VehicleId = data;
                $scope.vehicles.push(currentVehicle);
 
                //reset form
                $scope.vehicle = null;
                // $scope.addVehicleform.$setPristine(); //for form reset
 
                $('#vehicleModel').modal('hide');
            }).error(function (data) {
                $scope.error = "An Error has occured while Adding Vehicle! " + data.ExceptionMessage;
            });
        }
    };
 
    //edit Vehicle
    $scope.edit = function () {
        $scope.vehicle = this.vehicle;
        $scope.editMode = true;
        $('#vehicleModel').modal('show');
    };
 
    //update vehicle
    $scope.update = function () {
        var currentVehicle = this.vehicle;
        vehicleFactory.updateVehicle(currentVehicle).success(function (data) {
            currentVehicle.editMode = false;
 
            $('#vehicleModel').modal('hide');
        }).error(function (data) {
            $scope.error = "An Error has occured while Updating vehicle! " + data.ExceptionMessage;
        });
    };
 
    // delete vehicle
    $scope.delete = function () {
        currentVehicle = $scope.vehicle;
        vehicleFactory.deleteVehicle(currentVehicle).success(function (data) {
            $('#confirmModal').modal('hide');
            $scope.vehicles.pop(currentVehicle);
 
        }).error(function (data) {
            $scope.error = "An Error has occured while Deleting vehicle! " + data.ExceptionMessage;
 
            $('#confirmModal').modal('hide');
        });
    };
 
    //Model popup events
    $scope.showadd = function () {
        $scope.vehicle = null;
        $scope.editMode = false;
        $('#vehicleModel').modal('show');
    };
 
    $scope.showedit = function () {
        $('#vehicleModel').modal('show');
    };
 
    $scope.showconfirm = function (data) {
        $scope.vehicle = data;
        $('#confirmModal').modal('show');
    };
 
    $scope.cancel = function () {
        $scope.vehicle = null;
        $('#vehicleModel').modal('hide');
    }
 
    // initialize your vehicles data
    $scope.getAll();
});
