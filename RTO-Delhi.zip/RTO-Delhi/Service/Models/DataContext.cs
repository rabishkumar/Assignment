﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace VehicleApiService.Models
{
    public class DataContext:DbContext
    {
        public DataContext():base("VehicleService")
        {

        }

        public DbSet<Vehicle> Vehicle { get; set; }
    }
}